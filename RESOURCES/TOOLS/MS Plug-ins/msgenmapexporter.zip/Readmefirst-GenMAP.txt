*****************************************
* General Map Exporter for Milkshape 3d
*      by Rick J. Kelley AKA Rat 
*              4-20-03 
*            Version 1.3.1
*****************************************

This is a little something I have worked on for a bit that never quite worked as
hoped for. I dusted off the idea just recently when I thought of another way
to get a map exporter working.

There are a few things to keep in mind in its present form. Its certaintly far from
being done! For complex shapes it may cause the shape to look wierd when you
open it up in WorldCraft, (Havn't tried Hammer out yet), as I need to figure out
a better parsing routine. The Map format is a bit weird as its brushes are formed
by 3 vertices per side, no matter how many points the side seems to have. All the
sides have to be taken as a whole to form the brush. At present, some of the
geomety may appear to be in a simpler form than they were in the Milkshape
program. (A good example of this is the hemisphere that is in the window, it
has a fewer triangles when its exported, than it did in Milkshape).

To use this exporter as is right now, study the ms3d file I have included to
see what proper brushes should look like for the cylinders, and hemisphere shapes.

You may notice that I have a working way to export the light entity. To do this,
you need to name the first part of the object "light" and give it a material that
also is named "light." To add more than one light, just name your lights light01,
light02, and so on. (Take a look at the ms3d file for examples).

Also there is a glass feature in this version that will become see through in the
map export. I arbitrarly set this to 160 render amount right now and in the
future may add a way to input this by using the emmisive setting in Milkshape.
To use this feature, you will need to create an entity by making a box and
naming the first part of the object "glassb1." (The b1 at the end means
that I am going to expand the glass types later on). This will make this
a brush that becomes breakable and see through. To make more
than one glass pane in Milkshape, just name your glass like I did in the
example glassb101, glassb102 and so on.


KNOWN BUGS

If you do not assign a material to the object or group, it will cause milkshape
to crash. So for now just assign some material to all things you want to export.

CREDITS

CCCP for his help on how to get specific information on the material parse

TESTERS

Sylacs Thanks man for pointing out the gtkradiant error!
Mijacs Thanks for making sure it works in Hammer as I didnt want to install it!
DarthBobo Thanks m8 for help on the problem I had with the project setting.

=====================================================
History

Version 1.3.1 Release 4-20-03

Fixed a problem that was not allowing for the map load in gtkradient.

Fixed the bug where upon loading the map into worldcraft or Hammer it would
cause a pop up message of an error that was blank.

-------------------------------

Version 1.3 Release 4-19-03

Fixed material support to give texture names for the exported brushes so you
dont have to put the textures on in the map editor of your choice.

Added Deathmatch entity support.

Added breakable glass support with a see through value of 160 render amount.

-------------------------------

Version 1.0 Release 4-17-03

Export of  Generic MAP format for Level editing/building in Milkshape 3D.
Supports light entity placement.
