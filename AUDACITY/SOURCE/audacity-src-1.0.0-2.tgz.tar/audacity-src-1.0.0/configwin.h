// Microsoft Windows specific include file

// Use xaudio for importing MP3 on the mac
#define USE_XAUDIO
#define MP3SUPPORT

// Ogg Vorbis support
#define USE_LIBVORBIS

// ID3 support
#define USE_ID3LIB
