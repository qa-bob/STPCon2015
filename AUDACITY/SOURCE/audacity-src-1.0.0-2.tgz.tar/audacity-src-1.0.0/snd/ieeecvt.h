void ConvertToIeeeExtended(double num, char *bytes);
double ConvertFromIeeeExtended(unsigned char *bytes);
