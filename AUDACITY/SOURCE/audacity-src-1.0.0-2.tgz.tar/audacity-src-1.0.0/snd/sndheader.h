int snd_open_file(snd_type snd, long *flags);


void write_sndheader_finish(snd_type snd);

