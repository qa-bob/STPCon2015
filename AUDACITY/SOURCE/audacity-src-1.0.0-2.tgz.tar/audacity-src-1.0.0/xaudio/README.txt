This directory contains versions of the Xaudio library
for various platforms.  Audacity uses Xaudio to import
MP3 files.

The Xaudio library is a product of the Xaudio corporation
and is a commercial product.  It has been licensed to
Dominic Mazzoni, principal programmer of Audacity,
royalty-free, to include in the program.  Note that while
the rest of Audacity is under the GPL and you are free to
modify it and rerelease it, the Xaudio portion is not
free and if you wish to use it in a different or
derivative product you will need to obtain a License from
the Xaudio corporation.  For more information, visit
their website at http://www.xaudio.com/

The license agreement signed by Dominic Mazzoni is
also included in this directory.


