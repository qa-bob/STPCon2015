/**********************************************************************

  Audacity: A Digital Audio Editor

  PrefsDialog.h

  Joshua Haberman

**********************************************************************/

#ifndef __AUDACITY_PREFS_DIALOG__
#define __AUDACITY_PREFS_DIALOG__

#include <wx/defs.h>
#include <wx/dialog.h>
#include <wx/window.h>
#include <wx/event.h>
#include <wx/button.h>
#include <wx/notebook.h>

class PrefsDialog:public wxDialog {

 public:
   PrefsDialog(wxWindow * parent);
   ~PrefsDialog();

   void OnCategoryChange(wxCommandEvent & event);
   void OnOK(wxCommandEvent & event);
   void OnCancel(wxCommandEvent & event);

 private:
   wxNotebook *mCategories;
   wxButton *mOK;
   wxButton *mCancel;

   int mSelected;

 public:
    DECLARE_EVENT_TABLE()
};

#endif
