/**********************************************************************

  Audacity: A Digital Audio Editor

  VSTEffect.cpp

  Dominic Mazzoni
  
  This class implements a VST Plug-in effect.  The plug-in must be
  loaded in a platform-specific way and passed into the constructor,
  but from here this class handles the interfacing.  VST plug-ins
  are used in Cubase and other Steinberg products, and all of those
  files and the information within is copyrighted by Steinberg.

**********************************************************************/

#include "AEffect.h"            // VST API

#include <wx/defs.h>
#include <wx/button.h>
#include <wx/slider.h>
#include <wx/msgdlg.h>

#include "Effect.h"             // Audacity Effect base class
#include "VSTEffect.h"          // This class's header file

#ifdef __MACOSX__
#include <CodeFragments.h>
#endif

VSTEffect::VSTEffect(wxString pluginName, AEffect * aEffect)
{
   this->aEffect = aEffect;
   this->pluginName = pluginName;

   buffer = NULL;
   fInBuffer = NULL;
   fOutBuffer = NULL;

   isOpened = false;
}

wxString VSTEffect::GetEffectName()
{
   return pluginName + "...";
}

wxString VSTEffect::GetEffectAction()
{
   return "Performing VST Effect: \""+pluginName+"\"";
}

bool VSTEffect::Init()
{
   inputs = aEffect->numInputs;
   outputs = aEffect->numOutputs;

   mBlockSize = 0;

   if (inputs > 1) {
      TrackListIterator iter(mWaveTracks);
      VTrack *left = iter.First();
      while(left) {
         sampleCount lstart, rstart, llen, rlen;
         GetSamples((WaveTrack *)left, &lstart, &llen);
         
         if (left->linked) {
            VTrack *right = iter.Next();
            GetSamples((WaveTrack *)right, &rstart, &rlen);
            
            if (llen != rlen || ((WaveTrack *)left)->rate != ((WaveTrack *)right)->rate) {
               wxMessageBox("Sorry, VST Effects cannot be performed on stereo tracks where "
                            "the individual channels of the track do not match.");
               return false;
            }
         }
         
         left = iter.Next();
      }
   }

   return true;
}

bool VSTEffect::PromptUser()
{
   // Try to figure out how many parameters it takes by seeing how
   // many parameters have names
   char temp[8][256];
   numParameters = 0;
   do {
      long result;

      temp[numParameters][0] = 0;
      result = callDispatcher(aEffect, effGetParamName, numParameters, 0,
                              (void *) temp[numParameters], 0.0);

      if (temp[numParameters][0]==0)
         break;
      if (strstr(temp[numParameters], "ABOUT"))
         break;
      if (numParameters > 0
          && !strcmp(temp[numParameters], temp[numParameters - 1]))
         break;

      numParameters++;
   } while (temp[0] != 0 && numParameters < 8);

   if (numParameters > 0) {
      VSTEffectDialog d(mParent, pluginName, numParameters, this, aEffect);
      d.ShowModal();

      if (!d.GetReturnCode())
         return false;
   }

   return true;
}

bool VSTEffect::Process()
{
   TrackListIterator iter(mWaveTracks);
   int count = 0;
   VTrack *left = iter.First();
   VTrack *right;
   while(left) {
      sampleCount lstart, rstart, len;
      GetSamples((WaveTrack *)left, &lstart, &len);

      right = NULL;
      if (left->linked && inputs>1) {
         right = iter.Next();         
         GetSamples((WaveTrack *)right, &rstart, &len);
      }

      // Reset the effect
      callDispatcher(aEffect, effOpen, 0, 0, NULL, 0.0);
      
      bool success = ProcessStereo(count,
                                   (WaveTrack *)left, (WaveTrack *)right,
                                   lstart, rstart, len);

      if (!success)
         return false;
   
      left = iter.Next();
      count++;
   }
   
   return true;
}

bool VSTEffect::ProcessStereo(int count, WaveTrack *left, WaveTrack *right,
                              sampleCount lstart, sampleCount rstart, sampleCount len)
{
   if (mBlockSize == 0) {
      mBlockSize = left->GetMaxBlockSize() * 2;

      buffer = new sampleType[mBlockSize];
      fInBuffer = new float *[inputs];
      int i;
      for (i = 0; i < inputs; i++)
         fInBuffer[i] = new float[mBlockSize];
      fOutBuffer = new float *[outputs];
      for (i = 0; i < outputs; i++)
         fOutBuffer[i] = new float[mBlockSize];

   }

   callDispatcher(aEffect, effSetSampleRate, 0, 0, NULL,
                       (float) left->rate);
   callDispatcher(aEffect, effSetBlockSize, 0, mBlockSize * 2, NULL, 0.0);

   // Actually perform the effect here

   sampleCount originalLen = len;
   sampleCount ls = lstart;
   sampleCount rs = rstart;
   while (len) {
      int i;
      int block = mBlockSize;
      if (block > len)
         block = len;

      left->Get(buffer, ls, block);
      for (i = 0; i < block; i++)
         fInBuffer[0][i] = float (buffer[i] / 32767.);
      if (right) {
         right->Get(buffer, rs, block);
         for (i = 0; i < block; i++)
            fInBuffer[1][i] = float (buffer[i] / 32767.);
      }

      callProcessReplacing(aEffect, fInBuffer, fOutBuffer, block);

      for (i = 0; i < block; i++)
         buffer[i] = (sampleType) (fOutBuffer[0][i] * 32767.);
      left->Set(buffer, ls, block);
      
      if (right) {
         for (i = 0; i < block; i++)
            buffer[i] = (sampleType) (fOutBuffer[1][i] * 32767.);
         right->Set(buffer, rs, block);
      }      

      len -= block;
      ls += block;
      rs += block;
      
      if (inputs > 1) {      
         if (TrackGroupProgress(count, (ls-lstart)/(double)originalLen))
            break;
      }
      else {
         if (TrackProgress(count, (ls-lstart)/(double)originalLen))
            break;
      }
   }

   return true;
}

void VSTEffect::End()
{
   if (buffer) {
      int i;

      delete[]buffer;
      for (i = 0; i < inputs; i++)
         delete fInBuffer[i];
      for (i = 0; i < outputs; i++)
         delete fOutBuffer[i];
      delete[]fInBuffer;
      delete[]fOutBuffer;

   }
   buffer = NULL;
   fInBuffer = NULL;
   fOutBuffer = NULL;
}

const int VSTEFFECT_SLIDER_ID = 13100;

BEGIN_EVENT_TABLE(VSTEffectDialog, wxDialog)
    EVT_BUTTON(wxID_OK, VSTEffectDialog::OnOK)
    EVT_BUTTON(wxID_CANCEL, VSTEffectDialog::OnCancel)
    EVT_COMMAND_SCROLL(VSTEFFECT_SLIDER_ID, VSTEffectDialog::OnSlider)
    EVT_SLIDER(VSTEFFECT_SLIDER_ID, VSTEffectDialog::OnSlider)
END_EVENT_TABLE()

VSTEffectDialog::VSTEffectDialog(wxWindow * parent,
                                 wxString effectName,
                                 int numParams,
                                 VSTEffect * vst,
                                 AEffect * aEffect,
                                 const wxPoint & pos)
:wxDialog(parent, -1, effectName, pos, wxSize(320, 430),
          wxDEFAULT_DIALOG_STYLE)
{
   this->vst = vst;
   this->aEffect = aEffect;
   this->numParams = numParams;

   int y = 10;

   new wxStaticText(this, 0, "VST Plug-in parameters:", wxPoint(10, y),
                    wxSize(300, 15));
   y += 20;

   sliders = new wxSlider *[numParams];
   labels = new wxStaticText *[numParams];

   for (int p = 0; p < numParams; p++) {

      char paramName[256];
      vst->callDispatcher(aEffect, effGetParamName, p, 0,
                     (void *) paramName, 0.0);
      new wxStaticText(this, 0, wxString(paramName), wxPoint(10, y),
                       wxSize(85, 15));

      float val = vst->callGetParameter(aEffect, p);

      sliders[p] =
          new wxSlider(this, VSTEFFECT_SLIDER_ID,
                       1000 * val, 0, 1000,
                       wxPoint(100, y + 5), wxSize(200, 25));

      char label[256];
      vst->callDispatcher(aEffect, effGetParamDisplay, p, 0,
                          (void *) label, 0.0);
      char units[256];
      vst->callDispatcher(aEffect, effGetParamLabel, p, 0, (void *) units,
                          0.0);

      labels[p] =
          new wxStaticText(this, 0,
                           wxString::Format("%s %s", label, units),
                           wxPoint(10, y + 15), wxSize(85, 15));

      y += 35;
   }

   wxButton *ok =
       new wxButton(this, wxID_OK, "OK", wxPoint(110, y), wxSize(80, 30));
   wxButton *cancel =
       new wxButton(this, wxID_CANCEL, "Cancel", wxPoint(210, y),
                    wxSize(80, 30));
   y += 40;

   wxSize size;
   size.x = 320;
   size.y = y;

#ifdef __WXMSW__
   size.y += 20;
#endif

   Centre(wxBOTH | wxCENTER_FRAME);

   SetSize(size);
}

VSTEffectDialog::~VSTEffectDialog()
{
   // TODO: proper disposal here

   delete[]sliders;
   delete[]labels;
}

void VSTEffectDialog::OnSlider(wxCommandEvent & WXUNUSED(event))
{
   for (int p = 0; p < numParams; p++) {
      float val;

      val = sliders[p]->GetValue() / 1000.;
      vst->callSetParameter(aEffect, p, val);

      char label[256];
      vst->callDispatcher(aEffect, effGetParamDisplay, p, 0,
                          (void *) label, 0.0);
      char units[256];
      vst->callDispatcher(aEffect, effGetParamLabel, p, 0, (void *) units,
                          0.0);
      labels[p]->SetLabel(wxString::Format("%s %s", label, units));
   }
}

void VSTEffectDialog::OnOK(wxCommandEvent & WXUNUSED(event))
{
   EndModal(TRUE);
}

void VSTEffectDialog::OnCancel(wxCommandEvent & WXUNUSED(event))
{
   EndModal(FALSE);
}

#ifdef __MACOSX__

// Mac OS X methods
//
// Cross-platform VST plug-ins on the Mac are compiled as Carbon,
// CFM code.  Audacity is compiled as Carbon, Mach-O code.  Special care
// must be taken when calling funtions in the other mode - these
// functions make it easier.
//

// MachOFunctionPointerForCFMFunctionPointer(void *cfmfp)
//
// Borrowed from the Apple Sample Code file "CFM_MachO_CFM.c"
// This function allocates a block of CFM glue code which contains
// the instructions to call CFM routines

void *NewMachOFromCFM(void *cfmfp)
{
   UInt32 CFMTemplate[6] = {0x3D800000, 0x618C0000, 0x800C0000,
                            0x804C0004, 0x7C0903A6, 0x4E800420};
   UInt32	*mfp = (UInt32*)NewPtr(sizeof(CFMTemplate));
   
   mfp[0] = CFMTemplate[0] | ((UInt32)cfmfp >> 16);
   mfp[1] = CFMTemplate[1] | ((UInt32)cfmfp & 0xFFFF);
   mfp[2] = CFMTemplate[2];
   mfp[3] = CFMTemplate[3];
   mfp[4] = CFMTemplate[4];
   mfp[5] = CFMTemplate[5];
   MakeDataExecutable(mfp, sizeof(CFMTemplate));
   
   return(mfp);
}

void DisposeMachOFromCFM(void *ptr)
{
   DisposePtr((Ptr)ptr);
}

void *NewCFMFromMachO(void *machofp)
{
   void *result = NewPtr(8);
   ((void **)result)[0] = machofp;
   ((void **)result)[1] = result;

   return result;
}

void DisposeCFMFromMachO(void *ptr)
{
   DisposePtr((Ptr)ptr);
}

long VSTEffect::callDispatcher(AEffect * effect, long opCode,
                               long index, long value, void *ptr,
                               float opt)
{
   long rval;

   dispatcherFn fp = (dispatcherFn)NewMachOFromCFM(effect->dispatcher);
   rval = fp(effect, opCode, index, value, ptr, opt);
   DisposeMachOFromCFM(fp);

   return rval;
}

void VSTEffect::callProcess(AEffect * effect, float **inputs,
                            float **outputs, long sampleframes)
{
   processFn fp = (processFn)NewMachOFromCFM(effect->process);
   fp(effect, inputs, outputs, sampleframes);
   DisposeMachOFromCFM(fp);
}

void VSTEffect::callProcessReplacing(AEffect * effect, float **inputs,
                                     float **outputs, long sampleframes)
{
   processFn fp = (processFn)NewMachOFromCFM(effect->processReplacing);
   fp(effect, inputs, outputs, sampleframes);
   DisposeMachOFromCFM(fp);
}

void VSTEffect::callSetParameter(AEffect * effect, long index,
                                 float parameter)
{
   setParameterFn fp = (setParameterFn)NewMachOFromCFM(effect->setParameter);
   fp(effect, index, parameter);
   DisposeMachOFromCFM(fp);
}

float VSTEffect::callGetParameter(AEffect * effect, long index)
{
   float rval;

   getParameterFn fp = (getParameterFn)NewMachOFromCFM(effect->getParameter);
   rval = fp(effect, index);
   DisposeMachOFromCFM(fp);

   return rval;
}

#else // ifdef __MACOSX__

long VSTEffect::callDispatcher(AEffect * effect, long opCode,
                               long index, long value, void *ptr,
                               float opt)
{
   return effect->dispatcher(effect, opCode, index, value, ptr, opt);
}

void VSTEffect::callProcess(AEffect * effect, float **inputs,
                            float **outputs, long sampleframes)
{
   effect->process(effect, inputs, outputs, sampleframes);
}

void VSTEffect::callProcessReplacing(AEffect * effect, float **inputs,
                                     float **outputs, long sampleframes)
{
   effect->processReplacing(effect, inputs, outputs, sampleframes);
}

void VSTEffect::callSetParameter(AEffect * effect, long index,
                                 float parameter)
{
   effect->setParameter(effect, index, parameter);
}

float VSTEffect::callGetParameter(AEffect * effect, long index)
{
   return effect->getParameter(effect, index);
}

#endif


