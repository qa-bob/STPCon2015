/* configtemplate.h.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the <inttypes.h> header file. */
#undef HAVE_INTTYPES_H

/* Define if you have the <memory.h> header file. */
#undef HAVE_MEMORY_H

/* Define if you have the <stdint.h> header file. */
#undef HAVE_STDINT_H

/* Define if you have the <stdlib.h> header file. */
#undef HAVE_STDLIB_H

/* Define if you have the <strings.h> header file. */
#undef HAVE_STRINGS_H

/* Define if you have the <string.h> header file. */
#undef HAVE_STRING_H

/* Define if you have the <sys/stat.h> header file. */
#undef HAVE_SYS_STAT_H

/* Define if you have the <sys/types.h> header file. */
#undef HAVE_SYS_TYPES_H

/* Define if you have the <unistd.h> header file. */
#undef HAVE_UNISTD_H

/* Define if at least one supported library for mp3 functions is present */
#undef MP3SUPPORT

/* Define if you have the ANSI C header files. */
#undef STDC_HEADERS

/* Define if audio I/O happens with KDE/aRts soundserver */
#undef USE_ARTS

/* Define if audio I/O was not compiled in */
#undef USE_AUDIO_NONE

/* Define if id3lib is present */
#undef USE_ID3LIB

/* Define if mp3 support is implemented with the libmad library */
#undef USE_LIBMAD

/* Define if the ogg vorbis decoding library is present */
#undef USE_LIBVORBIS

/* Define if audio I/O happens with OSS */
#undef USE_OSS

/* Define if mp3 support is implemented with the xaudio library */
#undef USE_XAUDIO

/* Define to empty if `const' does not conform to ANSI C. */
#undef const

/* Define to `long' if <sys/types.h> does not define. */
#undef off_t

/* Define to `unsigned' if <sys/types.h> does not define. */
#undef size_t
