void allegro_write(Seq_ptr seq, FILE *file);

