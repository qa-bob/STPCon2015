void trace(char *format, ...);

